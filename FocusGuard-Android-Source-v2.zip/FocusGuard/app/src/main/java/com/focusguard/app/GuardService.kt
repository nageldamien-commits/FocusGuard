package com.focusguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.os.Build
import android.os.SystemClock
import java.util.Locale

class GuardService : AccessibilityService() {
 private var lastIntervention=0L
 private var braveCooldownUntil=0L
 private var lastBraveSeen=false
 override fun onServiceConnected() {
  super.onServiceConnected()
  if (Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(
   NotificationChannel("guard", "FocusGuard reminders", NotificationManager.IMPORTANCE_DEFAULT))
 }
 override fun onAccessibilityEvent(event: AccessibilityEvent?) {
  val prefs=getSharedPreferences("guard",MODE_PRIVATE)
  if (!prefs.getBoolean("enabled",false)) return
  val pkg=event?.packageName?.toString() ?: return
  val now=SystemClock.elapsedRealtime()
  if (pkg=="com.brave.browser" && prefs.getBoolean("brave",true)) {
   if (!lastBraveSeen && now>=braveCooldownUntil) braveCooldownUntil=now+10*60*1000L
   lastBraveSeen=true
   if (now<braveCooldownUntil && now-lastIntervention>3000L) interrupt("Brave is cooling down. Try another activity for a few minutes.")
   return
  }
  lastBraveSeen=false
  if (pkg!="com.zhiliaoapp.musically" || !prefs.getBoolean("tiktok",true)) return
  if (now-lastIntervention<12000L) return
  val root=rootInActiveWindow ?: return
  val text=StringBuilder()
  // Only process screen text in memory. Avoid reading messages by requiring a visible FYP label.
  collectText(root,text,0)
  val content=text.toString().lowercase(Locale.ROOT)
  val looksLikeFeed=content.contains("for you") || content.contains("for you page")
  if (!looksLikeFeed) return
  val keywords=prefs.getString("words", "")!!.split(",").map { it.trim().lowercase(Locale.ROOT) }.filter { it.length>=3 }
  if (keywords.any { content.contains(it) }) interrupt("A filtered phrase appeared on your feed. Consider skipping this video.")
 }
 private fun collectText(node: AccessibilityNodeInfo?, out:StringBuilder, depth:Int) {
  if (node==null || depth>16 || out.length>10000) return
  node.text?.let { out.append(' ').append(it.take(250)) }
  node.contentDescription?.let { out.append(' ').append(it.take(250)) }
  for (i in 0 until node.childCount) collectText(node.getChild(i),out,depth+1)
 }
 private fun interrupt(message:String) {
  lastIntervention=SystemClock.elapsedRealtime()
  performGlobalAction(GLOBAL_ACTION_HOME)
  try {
   val notification=Notification.Builder(this,"guard")
    .setSmallIcon(android.R.drawable.ic_lock_lock)
    .setContentTitle("FocusGuard")
    .setContentText(message)
    .setAutoCancel(true).build()
   getSystemService(NotificationManager::class.java).notify(7,notification)
  } catch (_:SecurityException) { /* Notifications are optional */ }
 }
 override fun onInterrupt() {}
}
