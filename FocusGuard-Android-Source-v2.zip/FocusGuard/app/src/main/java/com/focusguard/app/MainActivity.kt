package com.focusguard.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Switch
import android.widget.EditText
import android.view.ViewGroup

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val prefs = getSharedPreferences("guard", MODE_PRIVATE)
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(35,45,35,25) }
  fun label(s: String) { root.addView(TextView(this).apply { text=s; textSize=17f; setPadding(0,10,0,12) }) }
  label("FocusGuard v0.1")
  label("Your private, optional interruption tool. TikTok DMs are not intentionally scanned. Detection is experimental and may be wrong.")
  val enabled = Switch(this).apply { text="Enable protection"; isChecked=prefs.getBoolean("enabled",false) }
  enabled.setOnCheckedChangeListener { _, b -> prefs.edit().putBoolean("enabled",b).apply() }
  root.addView(enabled)
  val brave = Switch(this).apply { text="Brave 10-minute cooldown"; isChecked=prefs.getBoolean("brave",true) }
  brave.setOnCheckedChangeListener { _, b -> prefs.edit().putBoolean("brave",b).apply() }
  root.addView(brave)
  val tiktok = Switch(this).apply { text="Experimental FYP text checks"; isChecked=prefs.getBoolean("tiktok",true) }
  tiktok.setOnCheckedChangeListener { _, b -> prefs.edit().putBoolean("tiktok",b).apply() }
  root.addView(tiktok)
  label("Comma-separated words you personally want to avoid (checked only when FYP is identified):")
  val words = EditText(this).apply { setSingleLine(false); minLines=2; setText(prefs.getString("words", "")); hint="e.g. a hashtag or phrase" }
  root.addView(words, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
  val save=Button(this).apply { text="Save keywords"; setOnClickListener { prefs.edit().putString("words",words.text.toString()).apply() } }
  root.addView(save)
  val access=Button(this).apply { text="Open Accessibility settings"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
  root.addView(access)
  if (Build.VERSION.SDK_INT>=33) root.addView(Button(this).apply { text="Allow reminder notifications"; setOnClickListener { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),10) } })
  label("To stop: switch protection off here, or disable FocusGuard in Android Accessibility settings. No activity history is saved.")
  setContentView(root)
 }
}
