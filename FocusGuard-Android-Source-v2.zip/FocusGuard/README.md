# FocusGuard v0.1 (experimental Android source)

## Build
1. Open this folder as a project in Android Studio (recent version, JDK 17).
2. Let Gradle sync and install the Android SDK 35 if prompted.
3. Choose **Build > Build APK(s)**, or Run with a connected Android device.
4. Install the APK; enable FocusGuard in **Settings > Accessibility > Installed apps**.
5. Open FocusGuard, turn protection on, add your own comma-separated trigger keywords, and save.
6. On Android 13+, allow notifications for reminders if desired.

## What works / what doesn't
- Brave is interrupted during a 10-minute period starting on first detected launch. It is not an unbreakable lock: the user can turn it off, and Android/OEM power management may suspend the service. After the period ends Brave can be used; leaving and reopening later starts another cooldown.
- TikTok FYP detection is *heuristic*. It checks visible accessibility text for "For You" and user-provided phrases. It cannot recognize images or videos, and could miss triggers or cause false positives. TikTok UI and localization can change.
- TikTok DMs are not intentionally inspected. The app only processes accessibility text when TikTok is foregrounded, then discards it. If the screen has a 'For You' label while viewing other content, false positives are possible. No guarantee of DM isolation.
- No internet permission, no analytics, no stored screen content. Settings are stored locally.
- Android Accessibility is a sensitive permission. Review the source and only install software you trust.
- This is an untested starter project; Android Studio build/device testing is required. No APK is included.

## Future iterations
- Add explicit FYP-only detection based on carefully tested TikTok UI elements and accessibility tree IDs, without reading DM contents.
- Add a user-controlled 5-minute pause and scheduled quiet hours.
- Add a test suite and improve cooldown persistence across process restarts.
- Consider optional on-device frame classification only with explicit screen-capture consent and privacy safeguards; not part of v0.1.

## Build on GitHub using only a phone
Create a **private** GitHub repository, then upload the *contents* of this project folder to the repository root, including `.github/workflows/build-apk.yml`. On GitHub open **Actions → Build FocusGuard APK → Run workflow**. When the run finishes, open the run and download the `FocusGuard-debug-apk` artifact, unzip it, and install `app-debug.apk`. If GitHub hides dotfolders in your phone's file picker, create `.github/workflows/build-apk.yml` directly in GitHub using **Add file → Create new file**. This is an experimental project and is not guaranteed to compile or detect every trigger.
